# Evaluate a news article with Natural Language Processing

We will be building web tool that allows users to run Natural Language Processing (NLP) on articles using Aylien api.

## Run project
Below shows how to run in development and production mode.
### run in development mode
To start the webpack dev server at port 8080

` $ npm run build-dev`

### run in production mode
Generate the dist files and then start server at port 3000

` $ npm run build-prod`

` $ npm run start`


## Offline Functionality
The project have service workers set up in webpack to provide the offline functionality of our app.

## Testing

Testing is done with Jest. To run test, use the command 

`npm run test`. 

